# n8n AI Agent Pack — Vol. 2

17 production-grade n8n workflows. Import the JSON, follow the matching setup guide, done.

## What's inside
- **Customer Support Agent with Knowledge Base (RAG)** (Advanced, 30 minutes) — A chat agent that answers customer questions from YOUR docs - refund policy, shipping times, product specs - with conversation memory, and escalates to a human in Slack when it can't help.
- **Telegram Personal Assistant Agent (Calendar + Tasks + Search)** (Advanced, 30 minutes) — A Telegram bot that actually does things: 'schedule lunch with Sara Friday 1pm', 'add milk to my list', 'what's on tomorrow?' - it manages your Google Calendar and a task sheet conversationally, with memory.
- **SQL Data Analyst Agent - Chat with Your Database** (Advanced, 25 minutes) — Ask your Postgres database questions in plain English - 'revenue by month this year?', 'top 10 customers by orders?' - and get real answers computed from real queries, in a chat window anyone on the team can use.
- **Web Research Agent - Topic In, Cited Brief Out** (Advanced, 25 minutes) — Type a research question into a form; an agent searches the web, reads the top sources, and emails you a structured brief with citations - competitor scans, market checks, due diligence prep in minutes.
- **Shopify Order Support Agent - Where Is My Order?** (Advanced, 30 minutes) — A chat agent that answers the #1 support question - 'where's my order?' - by actually looking it up in Shopify: status, fulfillment, tracking. Handles returns policy questions from your rules and escalates edge cases.
- **Escalation Sub-Workflow (Companion for the Chat Agents)** (Beginner, 5 minutes) — The shared escalation path the support and order agents call: posts the customer's conversation summary to Slack and returns a hand-off message. Import once, wire into every agent.
- **Voice Note Agent - Speak Tasks, Get Organized Notes** (Intermediate, 20 minutes) — Send a voice note to your Telegram bot while walking; Whisper transcribes it, AI splits it into action items and notes, tasks land in your sheet with deadlines, and you get a clean summary back.
- **Multi-Agent Content Factory (Researcher > Writer > Editor)** (Intermediate, 20 minutes) — Three AI roles in a pipeline: a researcher gathers angles and facts, a writer drafts the article, an editor critiques and rewrites. Output quality lands visibly above any single-prompt draft.
- **CRM Enrichment Agent - Company Research on Autopilot** (Advanced, 20 minutes) — Add a lead with just an email and company name; the agent visits their website, figures out what they do, their size signals, and how your product fits - and writes it all back to the CRM row.
- **Competitor Watch Agent - Weekly Change Report** (Intermediate, 20 minutes) — Every Monday the agent reads your competitors' pricing and changelog pages, compares against last week's snapshot, and posts to Slack only what CHANGED - price moves, new features, new positioning.
- **Inbox Zero Agent - Daily Digest + Ready-to-Send Drafts** (Intermediate, 20 minutes) — At 7am the agent reads everything unanswered in your inbox, ranks it by what actually needs you, drafts replies for the routine half, and sends you one digest: 'these 3 need your brain, these 5 have drafts waiting'.
- **Social Repurposer Agent - One Article, Five Posts** (Intermediate, 15 minutes) — Paste a blog URL into a form; the agent reads it and produces a LinkedIn post, an X thread, an Instagram caption, a newsletter blurb, and three hook variants - all in an approval sheet, none auto-posted.
- **Feedback Insights Agent - Reviews and Surveys to Themes** (Intermediate, 15 minutes) — Once a week the agent reads every new review, NPS comment, and survey answer, clusters them into themes with counts and representative quotes, flags anything urgent, and posts the report where the team argues about roadmap.
- **Recruiting Outreach Personalizer - Bio In, Message Out** (Intermediate, 15 minutes) — Paste candidate rows into a sheet (name, role, a few lines from their profile); the agent writes genuinely personalized outreach referencing THEIR work, saved as Gmail drafts - 20 candidates personalized in the time one used to take.
- **Meeting Prep Agent - Briefed Before Every External Call** (Advanced, 20 minutes) — Every evening the agent looks at tomorrow's external meetings, researches each attendee's company website, and emails you one brief: who they are, what their company does, and two smart questions to open with.
- **Workflow Error Triage Agent - Your n8n Fixes Itself (Almost)** (Beginner, 10 minutes) — When any workflow in your instance fails, this one catches the error, has AI diagnose the root cause from the node name and error text, and posts a Slack alert with a plain-English diagnosis and the likely fix - instead of a raw stack trace.
- **Dormant Customer Win-Back Agent** (Intermediate, 15 minutes) — Monthly, the agent finds customers who went quiet 90+ days ago, writes each a personal win-back email referencing what they actually bought, and queues the drafts - reactivating old customers is the cheapest revenue you'll ever get.

## How to use
1. Open n8n (self-hosted or cloud).
2. Workflows > Import from File > pick any file in /workflows.
3. Open the matching guide in /setup-guides and follow the numbered steps.
4. Replace every REPLACE_WITH_* placeholder and the example URLs/emails with yours.

## Support
Questions or a workflow not fitting your stack? Reply through your purchase receipt and you'll get an answer within 24h.
Need something fully custom? https://www.fiverr.com/realkhan103/build-n8n-automations-and-ai-agents-that-run-your-business-on-autopilot

Free templates and updates: https://navkhan103.github.io
