# Competitor Watch Agent - Weekly Change Report

**What it's worth:** Every Monday the agent reads your competitors' pricing and changelog pages, compares against last week's snapshot, and posts to Slack only what CHANGED - price moves, new features, new positioning.

**Difficulty:** Intermediate · **Setup time:** 20 minutes

## How it works & setup
1. A Schedule Trigger runs Monday mornings.
2. A Code node holds your watchlist: competitor name + the URLs that matter (pricing, changelog, homepage).
3. An HTTP Request node fetches each page as readable text (via the r.jina.ai reader, so no HTML parsing).
4. Last week's snapshots live in a Google Sheet; the AI compares old vs new per competitor and reports ONLY meaningful changes - ignoring dates, cookie banners, and cosmetic noise.
5. New snapshots overwrite the sheet, and a Slack digest posts the changes (or a one-liner if nothing moved).
6. SETUP: edit the watchlist in the first Code node; create a sheet with columns Competitor, URL, Snapshot; connect Sheets, Slack, OpenAI; run once manually to seed snapshots - the first run reports 'baseline captured'.
7. TIP: pricing pages move markets - if you watch only one URL per competitor, make it pricing.

## Import
n8n > Workflows > Import from File > workflows/competitor-watch-agent.json
