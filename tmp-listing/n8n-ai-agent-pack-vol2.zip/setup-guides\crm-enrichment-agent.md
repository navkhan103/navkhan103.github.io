# CRM Enrichment Agent - Company Research on Autopilot

**What it's worth:** Add a lead with just an email and company name; the agent visits their website, figures out what they do, their size signals, and how your product fits - and writes it all back to the CRM row.

**Difficulty:** Advanced · **Setup time:** 20 minutes

## How it works & setup
1. A Google Sheets trigger watches your leads sheet for new rows (works the same with Airtable).
2. A Code node derives the company domain from the lead's email (skips free-mail addresses).
3. An AI Agent with a read_page tool visits the company homepage (and /about if needed), then summarizes: what they do, who they sell to, apparent size, and a one-line 'why our product fits' hypothesis.
4. A Google Sheets node writes the enrichment back to the same row - your CRM fills itself in while you sleep.
5. SETUP: sheet needs columns: Email, Company, Enriched, WhatTheyDo, Fit; connect Sheets on trigger and writer; set your OpenAI key; add a test row with a real company email.
6. TIP: edit the fit-hypothesis instruction to describe YOUR product - that line is what makes the enrichment actionable instead of trivia.
7. COST: one enrichment = 1-2 page reads + one mini completion, well under a cent.

## Import
n8n > Workflows > Import from File > workflows/crm-enrichment-agent.json
