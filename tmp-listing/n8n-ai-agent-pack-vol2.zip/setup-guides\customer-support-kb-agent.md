# Customer Support Agent with Knowledge Base (RAG)

**What it's worth:** A chat agent that answers customer questions from YOUR docs - refund policy, shipping times, product specs - with conversation memory, and escalates to a human in Slack when it can't help.

**Difficulty:** Advanced · **Setup time:** 30 minutes

## How it works & setup
1. A Chat Trigger gives you a hosted chat endpoint (n8n's built-in chat UI, embeddable on your site).
2. An AI Agent node runs the conversation with a strict system prompt: answer ONLY from the knowledge base tool, never invent policy, offer escalation when unsure.
3. An OpenAI Chat Model powers the agent; a Window Buffer Memory keeps the last 10 turns so follow-ups make sense.
4. A Vector Store tool holds your knowledge base - the companion loader flow (second tab in this workflow) ingests a Google Drive folder of your policy docs into the store.
5. An escalation tool posts the full conversation to Slack when the customer asks for a human or the agent can't answer.
6. SETUP: drop your policy/FAQ docs (txt or md) into a Drive folder; run the loader flow once to embed them; set your OpenAI key on the model and embeddings nodes; connect Slack; open the chat URL and ask a question your docs answer - then one they don't, to see the escalation.
7. TIP: re-run the loader whenever docs change. Keep each doc focused (one topic per file) - retrieval quality follows document hygiene.

## Import
n8n > Workflows > Import from File > workflows/customer-support-kb-agent.json
