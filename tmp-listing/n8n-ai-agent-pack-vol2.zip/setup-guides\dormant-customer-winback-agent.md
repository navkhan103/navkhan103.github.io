# Dormant Customer Win-Back Agent

**What it's worth:** Monthly, the agent finds customers who went quiet 90+ days ago, writes each a personal win-back email referencing what they actually bought, and queues the drafts - reactivating old customers is the cheapest revenue you'll ever get.

**Difficulty:** Intermediate · **Setup time:** 15 minutes

## How it works & setup
1. A Schedule Trigger runs on the 1st of each month.
2. A Google Sheets node reads your customers/orders sheet (works from a Shopify or Stripe export just as well - columns: Email, Name, LastOrderDate, LastProduct, TotalOrders).
3. A Code node selects customers whose last order is 90-365 days old (older than a year usually needs a different offer).
4. The AI writes each win-back email with rules: reference their actual last purchase naturally, one sentence of what's new since, a soft incentive placeholder you control, under 100 words, zero 'we miss you' guilt-tripping.
5. Each email saves as a Gmail draft; a Slack summary tells you how many are queued for review.
6. SETUP: connect the sheet, Gmail, Slack, OpenAI key; edit the what's-new line and the incentive placeholder in the prompt; run manually and read 5 drafts before sending anything.
7. TIP: send win-backs Tuesday-Thursday mornings, 20-30 at a time - deliverability likes consistency more than volume.

## Import
n8n > Workflows > Import from File > workflows/dormant-customer-winback-agent.json
