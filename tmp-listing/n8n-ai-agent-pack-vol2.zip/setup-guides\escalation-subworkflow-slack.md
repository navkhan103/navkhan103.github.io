# Escalation Sub-Workflow (Companion for the Chat Agents)

**What it's worth:** The shared escalation path the support and order agents call: posts the customer's conversation summary to Slack and returns a hand-off message. Import once, wire into every agent.

**Difficulty:** Beginner · **Setup time:** 5 minutes

## How it works & setup
1. This is a sub-workflow: it starts with an Execute Workflow Trigger, not a schedule or webhook - agents call it as their escalate_to_human tool.
2. It receives whatever context the agent passes (summary, customer question), posts it to your support Slack channel, and returns a polite hand-off sentence the agent relays to the customer.
3. SETUP: import this FIRST, connect Slack, save, and note the workflow's name. Then in each agent workflow, open the Escalate Tool node and select this workflow from the dropdown.
4. TIP: extend it later - create a ticket in your helpdesk, send an email, or page on-call - without touching any agent.

## Import
n8n > Workflows > Import from File > workflows/escalation-subworkflow-slack.json
