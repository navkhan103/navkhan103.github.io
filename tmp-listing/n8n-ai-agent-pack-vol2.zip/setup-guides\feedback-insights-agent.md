# Feedback Insights Agent - Reviews and Surveys to Themes

**What it's worth:** Once a week the agent reads every new review, NPS comment, and survey answer, clusters them into themes with counts and representative quotes, flags anything urgent, and posts the report where the team argues about roadmap.

**Difficulty:** Intermediate · **Setup time:** 15 minutes

## How it works & setup
1. A Schedule Trigger runs Friday afternoons.
2. A Google Sheets node reads this week's feedback rows (append feedback there from any source - Typeform, reviews, support tags - other workflows in this pack can feed it).
3. One AI call does the analysis: themes ranked by frequency, sentiment shifts, representative verbatim quotes per theme, and an URGENT section for churn threats or bug clusters.
4. The report posts to Slack and appends to a running Google Doc so you can see theme trends across months.
5. SETUP: feedback sheet columns: Date, Source, Text; connect Sheets, Slack, Docs; set your OpenAI key; backfill 20+ real feedback rows and run once - judge the themes against your own read.
6. TIP: the magic is longitudinal - after 6 weekly runs, ask the AI (or yourself) which themes are growing. That's your roadmap, written by customers.

## Import
n8n > Workflows > Import from File > workflows/feedback-insights-agent.json
