# Inbox Zero Agent - Daily Digest + Ready-to-Send Drafts

**What it's worth:** At 7am the agent reads everything unanswered in your inbox, ranks it by what actually needs you, drafts replies for the routine half, and sends you one digest: 'these 3 need your brain, these 5 have drafts waiting'.

**Difficulty:** Intermediate · **Setup time:** 20 minutes

## How it works & setup
1. A Schedule Trigger runs at 7:00 every weekday.
2. A Gmail node pulls unread + unanswered threads from the last 48 hours.
3. An AI pass triages each: NEEDS_YOU (decisions, negotiations, anything personal), ROUTINE (can be answered from context), IGNORE (newsletters, notifications).
4. For ROUTINE emails, a second AI call writes a reply in your voice - saved as a Gmail DRAFT on the thread, never auto-sent.
5. A digest email summarizes: what needs you (with one-line why), which drafts are waiting for review, what was ignored.
6. SETUP: connect Gmail; edit the voice-and-boundaries section of the drafting prompt (how formal, what you never commit to, your sign-off); set your OpenAI key; run once manually and read the drafts it produced before trusting the morning cadence.
7. SAFETY: drafts only - a human presses send. The triage prompt errs toward NEEDS_YOU when unsure.

## Import
n8n > Workflows > Import from File > workflows/inbox-zero-daily-agent.json
