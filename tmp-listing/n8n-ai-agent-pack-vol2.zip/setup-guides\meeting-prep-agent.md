# Meeting Prep Agent - Briefed Before Every External Call

**What it's worth:** Every evening the agent looks at tomorrow's external meetings, researches each attendee's company website, and emails you one brief: who they are, what their company does, and two smart questions to open with.

**Difficulty:** Advanced · **Setup time:** 20 minutes

## How it works & setup
1. A Schedule Trigger runs at 17:30 daily.
2. A Google Calendar node pulls tomorrow's events; a Code node keeps only meetings with external attendees (emails outside your domain) and extracts their company domains.
3. An AI Agent researches each external company with a read_page tool (homepage, about page) and drafts the brief section: what they do, size signals, recent-looking announcements, and two informed opening questions.
4. A Gmail node sends the combined briefing - one section per meeting, in calendar order.
5. SETUP: set YOUR email domain in the Code node filter; connect Calendar and Gmail; set your OpenAI key; check tomorrow has an external meeting and run manually once.
6. TIP: two good questions beat ten facts - the prompt weights question quality over trivia on purpose.

## Import
n8n > Workflows > Import from File > workflows/meeting-prep-agent.json
