# Multi-Agent Content Factory (Researcher > Writer > Editor)

**What it's worth:** Three AI roles in a pipeline: a researcher gathers angles and facts, a writer drafts the article, an editor critiques and rewrites. Output quality lands visibly above any single-prompt draft.

**Difficulty:** Intermediate · **Setup time:** 20 minutes

## How it works & setup
1. An n8n Form takes the topic, audience, and target keyword.
2. AGENT 1 - Researcher: produces an outline brief - angles, claims to verify, structure, search intent analysis.
3. AGENT 2 - Writer: writes the full draft from the brief, with strict style rules (no fluff, no 'in today's fast-paced world', concrete examples).
4. AGENT 3 - Editor: grades the draft against a rubric (hook, flow, evidence, style), then rewrites it fixing every weakness it found - critique-then-rewrite reliably beats write-once.
5. The final article plus the editor's change log lands in Google Docs, and you get a Slack ping with the link.
6. SETUP: add your OpenAI key to all three AI nodes; connect Google Docs and Slack; edit the writer's style rules to match your voice; submit a topic you know well and judge the result.
7. TIP: the roles are just prompts - turn the researcher into a technical fact-checker or the editor into a brand-voice enforcer by editing their system messages.
8. COST: about $0.10-0.20 per article with gpt-4o on writer/editor and mini on research.

## Import
n8n > Workflows > Import from File > workflows/multi-agent-content-factory.json
