# Recruiting Outreach Personalizer - Bio In, Message Out

**What it's worth:** Paste candidate rows into a sheet (name, role, a few lines from their profile); the agent writes genuinely personalized outreach referencing THEIR work, saved as Gmail drafts - 20 candidates personalized in the time one used to take.

**Difficulty:** Intermediate · **Setup time:** 15 minutes

## How it works & setup
1. A Google Sheets trigger watches for new candidate rows (Name, Role, ProfileNotes, Email, Status).
2. The AI writes outreach with hard rules: reference something specific from their profile notes in sentence one, say why THIS role fits THEIR trajectory, under 120 words, zero recruiter cliches ('rockstar', 'fast-paced environment', 'wear many hats' are banned in the prompt).
3. A second AI pass plays the candidate: 'would this message annoy you?' - messages that fail get rewritten once automatically.
4. The result saves as a Gmail draft to the candidate's email and the row's Status flips to 'draft ready'.
5. SETUP: connect Sheets and Gmail; edit the role/company context block in the prompt (what you're hiring for, why it's actually good); set your OpenAI key; add 3 candidates you know and read the drafts critically.
6. ETHICS: drafts, never auto-send - a human owns every message. Paste only profile info the candidate made public.

## Import
n8n > Workflows > Import from File > workflows/recruiting-outreach-personalizer.json
