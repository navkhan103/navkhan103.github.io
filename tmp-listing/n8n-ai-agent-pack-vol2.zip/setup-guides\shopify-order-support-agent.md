# Shopify Order Support Agent - Where Is My Order?

**What it's worth:** A chat agent that answers the #1 support question - 'where's my order?' - by actually looking it up in Shopify: status, fulfillment, tracking. Handles returns policy questions from your rules and escalates edge cases.

**Difficulty:** Advanced · **Setup time:** 30 minutes

## How it works & setup
1. A Chat Trigger hosts the chat (embed the URL on your contact page or link it from order emails).
2. The agent verifies the customer by asking for order number AND email before revealing anything - both must match the Shopify lookup.
3. A Shopify tool fetches the order by name/number; the agent reads status, fulfillment, and tracking from the result.
4. Your return/exchange policy lives in the system prompt so policy answers are instant and consistent.
5. Anything off-script - refund demands, damaged items, angry customers - triggers the escalate tool, which posts the conversation to Slack.
6. SETUP: connect a Shopify access token (read_orders scope only); paste your actual returns policy into the system prompt where marked; connect Slack for escalations; set your OpenAI key; test with a real order number + email from your store, then with a mismatched pair to verify it refuses.
7. PRIVACY: the agent only ever sees one order at a time, only after number+email match, and the read-only token can't modify anything.

## Import
n8n > Workflows > Import from File > workflows/shopify-order-support-agent.json
