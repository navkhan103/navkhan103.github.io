# Social Repurposer Agent - One Article, Five Posts

**What it's worth:** Paste a blog URL into a form; the agent reads it and produces a LinkedIn post, an X thread, an Instagram caption, a newsletter blurb, and three hook variants - all in an approval sheet, none auto-posted.

**Difficulty:** Intermediate · **Setup time:** 15 minutes

## How it works & setup
1. An n8n Form takes the article URL and an optional angle note.
2. An HTTP Request fetches the article as readable text.
3. One AI call produces all five formats in strict JSON: each platform gets its own rules (LinkedIn: hook line + whitespace + no links in body; X: numbered thread under 280/tweet; Instagram: caption + hashtag block; newsletter: 60-word teaser).
4. A Code node validates and splits the formats into rows.
5. Everything lands in a Google Sheet (one row per platform, Status column = 'review') - your approval queue, not an auto-poster.
6. SETUP: connect Sheets (columns: Date, Platform, Content, Hooks, Status, SourceURL); set your OpenAI key; edit the voice rules in the prompt; submit a published article and grade each format.
7. TIP: add a Buffer/Typefully HTTP node reading rows where Status = 'approved' if you want scheduled posting - deliberately left out so nothing ships unreviewed.

## Import
n8n > Workflows > Import from File > workflows/social-repurposer-agent.json
