# SQL Data Analyst Agent - Chat with Your Database

**What it's worth:** Ask your Postgres database questions in plain English - 'revenue by month this year?', 'top 10 customers by orders?' - and get real answers computed from real queries, in a chat window anyone on the team can use.

**Difficulty:** Advanced · **Setup time:** 25 minutes

## How it works & setup
1. A Chat Trigger provides the chat UI (n8n hosted page, shareable with your team).
2. An AI Agent translates questions into SQL using a schema description you provide in the system prompt, runs them through the Postgres tool, and explains results in plain language.
3. The Postgres tool is READ-ONLY by design: the system prompt forbids mutations and the recommended DB user has SELECT-only grants.
4. Window Buffer Memory lets follow-ups work: 'now just for Canada' after a revenue question.
5. SETUP: create a read-only Postgres user (GRANT SELECT); connect it in the Postgres tool node; paste your table schemas into the system prompt where marked (table names, columns, what each means); set your OpenAI key; ask 'how many rows in <your biggest table>?' as a smoke test.
6. TIP: the schema description is the quality lever. Two lines per table - what it contains and which columns matter - beats a raw column dump.
7. SAFETY: never connect a write-capable user. The prompt guards against DROP/UPDATE, but grants are the real fence.

## Import
n8n > Workflows > Import from File > workflows/sql-data-analyst-agent.json
