# Telegram Personal Assistant Agent (Calendar + Tasks + Search)

**What it's worth:** A Telegram bot that actually does things: 'schedule lunch with Sara Friday 1pm', 'add milk to my list', 'what's on tomorrow?' - it manages your Google Calendar and a task sheet conversationally, with memory.

**Difficulty:** Advanced · **Setup time:** 30 minutes

## How it works & setup
1. A Telegram Trigger receives your messages to the bot.
2. An AI Agent interprets each message and decides which tool to use - no commands to memorize, just talk.
3. Tool 1: create_event adds events to Google Calendar (the agent extracts title, date, time, duration from your sentence).
4. Tool 2: check_schedule reads your calendar for any day you ask about.
5. Tool 3: add_task / list_tasks manage a running task list in Google Sheets.
6. A Window Buffer Memory keyed to your chat ID means follow-ups like 'move it to 2pm' work.
7. The agent's reply goes back to Telegram.
8. SETUP: create a bot with @BotFather and connect it; connect Google Calendar and a Sheet with columns Task, Added, Done; set your OpenAI key; message the bot 'add dentist Tuesday 3pm' and watch the calendar.
9. SECURITY: the first Code node whitelists YOUR Telegram user ID - edit it so only you can command the bot.

## Import
n8n > Workflows > Import from File > workflows/telegram-personal-assistant-agent.json
