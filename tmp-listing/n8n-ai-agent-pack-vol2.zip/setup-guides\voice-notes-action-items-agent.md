# Voice Note Agent - Speak Tasks, Get Organized Notes

**What it's worth:** Send a voice note to your Telegram bot while walking; Whisper transcribes it, AI splits it into action items and notes, tasks land in your sheet with deadlines, and you get a clean summary back.

**Difficulty:** Intermediate · **Setup time:** 20 minutes

## How it works & setup
1. A Telegram Trigger receives voice messages from your bot.
2. A Telegram node downloads the voice file (OGG).
3. An OpenAI audio node transcribes it with Whisper - accents, background noise, brand names all handled well.
4. An AI step structures the transcript: action items (with owner and deadline if you said one), decisions, and reference notes - as strict JSON.
5. A Code node validates the JSON; tasks append to your Google Sheet, and the bot replies with the organized summary.
6. SETUP: create a bot with @BotFather; connect Telegram (trigger + reply nodes use the same credential); add your OpenAI key to both AI nodes; connect the task sheet (columns: Task, Deadline, Source, Added); send a rambling 60-second voice note and watch it become a tidy list.
7. COST: Whisper is $0.006/minute - a heavy week of voice notes costs pennies.

## Import
n8n > Workflows > Import from File > workflows/voice-notes-action-items-agent.json
