# Web Research Agent - Topic In, Cited Brief Out

**What it's worth:** Type a research question into a form; an agent searches the web, reads the top sources, and emails you a structured brief with citations - competitor scans, market checks, due diligence prep in minutes.

**Difficulty:** Advanced · **Setup time:** 25 minutes

## How it works & setup
1. An n8n Form Trigger takes the research question and desired depth.
2. An AI Agent plans searches, calls the web_search tool (SerpAPI - free tier is plenty), and fetches promising pages with the read_page tool.
3. The agent is prompted to distinguish facts from claims, note dates, and cite the source URL for every load-bearing statement.
4. A Gmail node sends the finished brief: summary up top, findings grouped by theme, source list at the bottom.
5. SETUP: get a free SerpAPI key (100 searches/month) and put it in the search tool's query string; set your OpenAI key; connect Gmail and set your address; submit a question you know the answer to and grade the brief.
6. TIP: gpt-4o writes noticeably better briefs than mini here - research synthesis is where the model tier shows.
7. COST: one brief = 3-6 searches + 2-4 page reads + one long completion, roughly $0.05-0.15 with gpt-4o.

## Import
n8n > Workflows > Import from File > workflows/web-research-agent-briefs.json
