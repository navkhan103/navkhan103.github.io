# Workflow Error Triage Agent - Your n8n Fixes Itself (Almost)

**What it's worth:** When any workflow in your instance fails, this one catches the error, has AI diagnose the root cause from the node name and error text, and posts a Slack alert with a plain-English diagnosis and the likely fix - instead of a raw stack trace.

**Difficulty:** Beginner · **Setup time:** 10 minutes

## How it works & setup
1. An Error Trigger fires whenever a workflow that has this set as its error workflow fails.
2. A Code node extracts the essentials: which workflow, which node, the error message, and the execution URL.
3. An AI call diagnoses: expired credential? Rate limit? Changed field name? Bad data shape? - and suggests the specific first thing to check.
4. A Slack node posts the human-readable incident card with a link to the failed execution.
5. SETUP: import and activate; in EVERY workflow you care about, open Settings and set 'Error workflow' to this one; connect Slack and your OpenAI key; force an error somewhere (rename a sheet) to test.
6. TIP: the AI sees only node name + error text, no payload data - safe to use even on workflows handling sensitive rows.

## Import
n8n > Workflows > Import from File > workflows/workflow-error-triage-agent.json
